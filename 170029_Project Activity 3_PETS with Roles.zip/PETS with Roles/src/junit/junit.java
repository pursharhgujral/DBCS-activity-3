package junit;



import static org.junit.Assert.assertEquals;

import org.junit.Test;


import junit.*;

public class junit {

    @Test
    public void test1() {
        methods tester = new methods(); // MyClass is tested

        // assert statements
        assertEquals("Name is already present in DataBase!", tester.insertDBlifecycle("pursharth","student"), 
        		"Name is already present in DataBase!");
       
    }
    @Test
    public void test2() {
        methods tester = new methods(); // MyClass is tested

        // assert statements
       
        assertEquals("Database Updated", tester.insertDBlifecycle("vai12we","intern"), "DataBase Updated");
    }
}