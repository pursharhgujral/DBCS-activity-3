package junit;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;



public class methods {

	
	public String insertDBlifecycle(String theItemName, String theItemDescription){
	    
	     
	        	try {
	        		Class.forName("com.mysql.cj.jdbc.Driver");  
				     
					   Connection con=DriverManager.getConnection("jdbc:mysql://localhost/week13_project?autoReconnect=true&useSSL=false", "root" , "309919");  
					     
					   System.out.println("Connected to Database");
					   Statement stmt = con.createStatement();
					   stmt.execute("INSERT INTO lifecycle (name,description) VALUES ( '" +theItemName + "'," +" "+ "'" +theItemDescription + "'" + ")");

						
							System.out.println("data updated successfully in life cycle");
					   con.close();  
					     
					  
	        	}
	        	catch(Exception e) {
	        		
	        		 return"Name is already present in DataBase!";
	        	
	        	}
				return theItemDescription;
	
	     }
}

